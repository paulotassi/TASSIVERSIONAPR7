using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Enemy : MonoBehaviour
{
    /*this class exsists purely to determin if something is an enemy with the component and to give everything health*/
    protected int health;
}
